import React from 'react';
 import '../../App.css';

function Services() {
  return 
  <h1 className='services'>SERVICES</h1>;
  <div className="services-background">
  hiiiiiiiii

  </div>
}
export default Services