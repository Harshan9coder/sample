import React from "react";
const PlaceDetails=()=>{
    return(
        <div>PlaceDetails</div>
    )

}
export default PlaceDetails